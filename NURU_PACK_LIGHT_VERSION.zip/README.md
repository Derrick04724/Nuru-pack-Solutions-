
NURU PACK SOLUTIONS - Light Starter (React + FastAPI)
-----------------------------------------------------

Admin login email (pre-seeded in .env.example): odariderrick3@gmail.com
Admin password (change this after deploy): ChangeMe123!

Quick start (local):
1. Backend:
   - cd backend
   - pip install -r requirements.txt
   - uvicorn app.main:app --reload --port 8000
2. Frontend:
   - cd frontend
   - npm install
   - npm run dev
Or use docker-compose up --build
