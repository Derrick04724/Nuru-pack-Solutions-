from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from io import BytesIO

def generate_receipt_pdf(db_session, sale_id):
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    y = height - 50
    c.setFont('Helvetica-Bold', 14)
    c.drawString(50, y, 'NURU PACK SOLUTIONS')
    c.setFont('Helvetica', 10)
    c.drawString(50, y-16, 'Smart. Simple. Sustainable.')
    c.drawString(50, y-40, f"Sale ID: {sale_id}")
    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer
