from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import products, sales, reports, customers
import os

def create_app():
    app = FastAPI(title="NURU PACK SOLUTIONS (Light)")
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
    app.include_router(products.router, prefix="/api/products")
    app.include_router(customers.router, prefix="/api/customers")
    app.include_router(sales.router, prefix="/api/sales")
    app.include_router(reports.router, prefix="/api/reports")
    return app

app = create_app()
