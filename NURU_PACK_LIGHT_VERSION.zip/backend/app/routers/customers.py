from fastapi import APIRouter
from pydantic import BaseModel
from sqlalchemy import create_engine, Table, MetaData, Column, Integer, String
from sqlalchemy.orm import sessionmaker
import os

router = APIRouter()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./nuru_light.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
metadata = MetaData()
customers = Table('customers', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String(200)),
    Column('phone', String(50)),
    Column('email', String(120)),
    Column('location', String(200))
)
metadata.create_all(engine)
Session = sessionmaker(bind=engine)

class CustomerIn(BaseModel):
    name: str
    phone: str = ""
    email: str = ""
    location: str = ""

@router.get("/")
def list_customers():
    s = Session()
    res = s.execute(customers.select()).fetchall()
    return [dict(r) for r in res]

@router.post("/")
def add_customer(c: CustomerIn):
    s = Session()
    r = s.execute(customers.insert().values(name=c.name, phone=c.phone, email=c.email, location=c.location))
    s.commit()
    return {"id": r.lastrowid}
