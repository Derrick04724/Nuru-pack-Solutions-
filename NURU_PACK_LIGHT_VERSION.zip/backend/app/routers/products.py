from fastapi import APIRouter
from pydantic import BaseModel
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Table, MetaData, Column, Integer, String, Numeric
import os

router = APIRouter()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./nuru_light.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
metadata = MetaData()
products = Table('products', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String(200)),
    Column('category', String(100)),
    Column('buying_price', Numeric, default=0),
    Column('selling_price', Numeric, default=0),
    Column('quantity', Integer, default=0)
)
metadata.create_all(engine)
Session = sessionmaker(bind=engine)

class ProductIn(BaseModel):
    name: str
    category: str = "Packaging"
    buying_price: float = 0.0
    selling_price: float = 0.0
    quantity: int = 0

@router.get("/")
def list_products():
    s = Session()
    res = s.execute(products.select()).fetchall()
    return [dict(r) for r in res]

@router.post("/")
def add_product(p: ProductIn):
    s = Session()
    r = s.execute(products.insert().values(name=p.name, category=p.category, buying_price=p.buying_price, selling_price=p.selling_price, quantity=p.quantity))
    s.commit()
    return {"id": r.lastrowid}
