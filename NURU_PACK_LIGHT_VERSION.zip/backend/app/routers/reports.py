from fastapi import APIRouter
from sqlalchemy import create_engine, func
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Table, MetaData, Column, Integer, Numeric
import os

router = APIRouter()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./nuru_light.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
metadata = MetaData()
products = Table('products', metadata, autoload_with=engine)
sales = Table('sales', metadata, autoload_with=engine)
metadata.create_all(engine)
Session = sessionmaker(bind=engine)

@router.get("/summary")
def summary():
    s = Session()
    total_sales = s.execute(func.coalesce(func.sum(sales.c.total),0)).scalar() or 0
    # simple low stock count threshold 20
    low_stock = s.execute("SELECT COUNT(*) FROM products WHERE quantity <= 20").scalar() if True else 0
    return {"total_sales": float(total_sales), "low_stock_count": low_stock}
