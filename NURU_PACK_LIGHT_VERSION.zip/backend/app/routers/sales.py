from fastapi import APIRouter, HTTPException, Response
from pydantic import BaseModel
from sqlalchemy import create_engine, Table, MetaData, Column, Integer, Numeric, ForeignKey, String, DateTime
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from app.utils.receipts import generate_receipt_pdf
import os

router = APIRouter()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./nuru_light.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
metadata = MetaData()
products = Table('products', metadata, autoload_with=engine)
sales = Table('sales', metadata,
    Column('id', Integer, primary_key=True),
    Column('customer_name', String(200)),
    Column('date', DateTime),
    Column('total', Numeric)
)
sale_items = Table('sale_items', metadata,
    Column('id', Integer, primary_key=True),
    Column('sale_id', Integer, ForeignKey('sales.id')),
    Column('product_id', Integer),
    Column('quantity', Integer),
    Column('subtotal', Numeric)
)
metadata.create_all(engine)
Session = sessionmaker(bind=engine)

class SaleItemIn(BaseModel):
    product_id: int
    quantity: int

class SaleIn(BaseModel):
    customer_name: str
    items: list[SaleItemIn]
    payment_mode: str = "Cash"

@router.post("/")
def create_sale(payload: SaleIn):
    s = Session()
    total = 0
    # validate and deduct stock
    for it in payload.items:
        prod = s.execute(products.select().where(products.c.id == it.product_id)).fetchone()
        if not prod:
            raise HTTPException(400, f"Product {it.product_id} not found")
        if prod.quantity < it.quantity:
            raise HTTPException(400, f"Insufficient stock for {prod.name}")
        total += float(prod.selling_price) * int(it.quantity)
    r = s.execute(sales.insert().values(customer_name=payload.customer_name, date=datetime.utcnow(), total=total))
    sale_id = r.lastrowid
    for it in payload.items:
        p = s.execute(products.select().where(products.c.id == it.product_id)).fetchone()
        s.execute(products.update().where(products.c.id == it.product_id).values(quantity=p.quantity - it.quantity))
        s.execute(sale_items.insert().values(sale_id=sale_id, product_id=it.product_id, quantity=it.quantity, subtotal=float(p.selling_price)*it.quantity))
    s.commit()
    buffer = generate_receipt_pdf(s, sale_id)
    return Response(content=buffer.read(), media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=receipt_{sale_id}.pdf"})
