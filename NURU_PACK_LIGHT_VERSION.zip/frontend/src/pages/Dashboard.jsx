import React, {useEffect, useState} from 'react'
import axios from 'axios'
export default function Dashboard(){
  const [summary, setSummary] = useState({})
  useEffect(()=>{
    axios.get((import.meta.env.VITE_API_URL || 'http://localhost:8000') + '/api/reports/summary').then(r=> setSummary(r.data)).catch(()=>{})
  },[])
  return (
    <div style={{padding:20}}>
      <h1>NURU PACK SOLUTIONS</h1>
      <p>Smart. Simple. Sustainable.</p>
      <div style={{display:'flex', gap:20}}>
        <div style={{padding:10, border:'1px solid #ddd'}}><h3>Total Sales</h3><p>{summary.total_sales}</p></div>
        <div style={{padding:10, border:'1px solid #ddd'}}><h3>Low Stock</h3><p>{summary.low_stock_count}</p></div>
      </div>
    </div>
  )
}
