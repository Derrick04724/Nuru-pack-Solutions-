import React, {useEffect, useState} from 'react'
import axios from 'axios'
export default function Sales(){
  const [products, setProducts] = useState([])
  const [customer, setCustomer] = useState('Walk-in')
  const [items, setItems] = useState([{product_id:'', quantity:1}])
  useEffect(()=>{
    axios.get((import.meta.env.VITE_API_URL || 'http://localhost:8000') + '/api/products').then(r=> setProducts(r.data)).catch(()=>{})
  },[])
  function addRow(){ setItems([...items, {product_id:'', quantity:1}]) }
  function updateRow(i, key, val){ const c = [...items]; c[i][key]=val; setItems(c) }
  async function submit(e){
    e.preventDefault()
    const payload = { customer_name: customer, items: items.map(it=>({product_id: parseInt(it.product_id), quantity: parseInt(it.quantity)})), payment_mode: 'Cash' }
    try{
      const res = await axios.post((import.meta.env.VITE_API_URL || 'http://localhost:8000') + '/api/sales', payload, { responseType: 'blob' })
      const url = window.URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' }))
      const a = document.createElement('a'); a.href = url; a.download = 'receipt.pdf'; document.body.appendChild(a); a.click()
    }catch(e){ alert('Error creating sale: ' + (e.response?.data || e.message)) }
  }
  return (
    <div style={{padding:20}}>
      <h2>New Sale</h2>
      <form onSubmit={submit}>
        <div><label>Customer Name</label><input value={customer} onChange={e=>setCustomer(e.target.value)} /></div>
        {items.map((it,i)=> (
          <div key={i}>
            <select value={it.product_id} onChange={e=> updateRow(i,'product_id', e.target.value)}>
              <option value=''>Select product</option>
              {products.map(p=> <option key={p.id} value={p.id}>{p.name} — {p.quantity}</option>)}
            </select>
            <input type="number" value={it.quantity} onChange={e=> updateRow(i,'quantity', e.target.value)} />
          </div>
        ))}
        <button type="button" onClick={addRow}>Add item</button>
        <button type="submit">Submit Sale (download receipt)</button>
      </form>
    </div>
  )
}
