import React, {useEffect, useState} from 'react'
import axios from 'axios'
export default function Inventory(){
  const [products, setProducts] = useState([])
  useEffect(()=>{
    axios.get((import.meta.env.VITE_API_URL || 'http://localhost:8000') + '/api/products').then(r=> setProducts(r.data)).catch(()=>{})
  },[])
  return (
    <div style={{padding:20}}>
      <h2>Inventory</h2>
      <ul>{products.map(p=> <li key={p.id}>{p.name} — {p.quantity}</li>)}</ul>
    </div>
  )
}
