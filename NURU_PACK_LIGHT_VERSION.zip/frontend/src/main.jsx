import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Sales from './pages/Sales'
import Inventory from './pages/Inventory'
import './styles.css'

function App(){
  return (
    <BrowserRouter>
      <div className="nav"><Link to="/">Dashboard</Link> | <Link to="/sales">Sales</Link> | <Link to="/inventory">Inventory</Link></div>
      <Routes>
        <Route path="/" element={<Dashboard/>} />
        <Route path="/sales" element={<Sales/>} />
        <Route path="/inventory" element={<Inventory/>} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App/>)
